

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <!-- Page Heading -->

        <div class="card shadow mb-4 col-6 mx-auto">
            <div class=" py-3">
                <h2 class="m-0 font-weight-bold text-primary text-center">Edit Anggota</h2>
            </div>
            <div class="card-body">
                <form class="user" action="<?php echo e(route('admin.updateAnggota', $user->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class="form-group">
                        <label for="name">Nama </label>
                        <input type="text" class="form-control" id="name" name="name" placeholder="Masukkan Nama" value="<?php echo e($user->name); ?>" required autofocus>
                    </div>
                    <div class="form-group">
                        <label for="position">Jabatan</label>
                        <input type="text" class="form-control" id="position" name="position" placeholder="Masukkan Jabatan"value="<?php echo e($user->position); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="rank">Pangkat</label>
                        <input type="text" class="form-control" id="rank" name="rank" placeholder="Masukkan Pangkat" value="<?php echo e($user->rank); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="nrp">NRP</label>
                        <input type="nrp" class="form-control" id="nrp" name="nrp" placeholder="Masukkan NRP" value="<?php echo e($user->nrp); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="role">Role</label>
                        <select class="form-control" id="role" name="role" required>
                            <option value="" disabled><b>Pilih Role</b></option>
                            <option value="admin" <?php echo e($user->role == 'admin' ? 'selected' : ''); ?>>Admin</option>
                            <option value="user" <?php echo e($user->role == 'user' ? 'selected' : ''); ?>>User</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="password">Password</label>
                        <input type="password" class="form-control" id="password" name="password" placeholder="Isi Password Jika Ingin Diubah">
                    </div>
                        <button type="submit" class="btn btn-primary">Edit</button>
                        <a href="/admin/anggota" class="btn btn-danger">Cancel</a>
                </form>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\presensi-polres\resources\views/admin/editAnggota.blade.php ENDPATH**/ ?>