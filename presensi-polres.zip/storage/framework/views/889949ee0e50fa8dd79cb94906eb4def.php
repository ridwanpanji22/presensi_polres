<footer class="sticky-footer bg-white">
    <div class="container my-auto">
        <div class="copyright text-center my-auto">
            <span>Copyright &copy; Anak Magang 2024</span>
        </div>
    </div>
</footer><?php /**PATH C:\laragon\www\presensi-polres\resources\views/admin/partials/footer.blade.php ENDPATH**/ ?>